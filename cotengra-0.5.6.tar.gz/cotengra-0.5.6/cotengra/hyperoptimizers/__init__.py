"""Different hyper (or meta) optimizers for sampling paramtetrized trees.
"""
