"""Parametrized contraction tree finders.
"""
