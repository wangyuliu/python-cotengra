"""Potentially useful but experimental (untested) features,
"""
