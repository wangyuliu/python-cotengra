# Examples

```{toctree}
:caption: Examples
:maxdepth: 2

examples/ex_large_output_lazy.ipynb
examples/ex_compressed_contraction.ipynb
```
